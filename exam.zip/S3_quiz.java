package exam;

import java.util.Random;
import java.util.Scanner;

public class S3_quiz {
public static void main(String[] args) {
 Scanner a = new Scanner(System.in);
 int n =a.nextInt();
 int[] b = {1,2,3,4,5};
if (n >= 0 && n < b.length) {
	System.out.println(b[n]);
} 
}
}

